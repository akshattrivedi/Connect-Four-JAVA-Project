package classes;

import javax.swing.JOptionPane;



public class pclass {
    
    //Data member
    public static int players,turn;
    public static int a[] = new int[] {0,0,0,0,0,0,0};;
    public static int b[] = new int[] {0,0,0,0,0,0,0};;
    public static int c[] = new int[] {0,0,0,0,0,0,0};;
    public static int d[] = new int[] {0,0,0,0,0,0,0};;
    public static int e[] = new int[] {0,0,0,0,0,0,0};;
    public static int f[] = new int[] {0,0,0,0,0,0,0};;
    public static int g[] = new int[] {0,0,0,0,0,0,0};;
    public static String p1 = "Player 1";
    public static String p2 = "Player 2";
    public static String p2c = "";
    public static String p1c = "";
}
